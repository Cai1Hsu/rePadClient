// JavaScript Document
if (typeof(JSON) == 'undefined') {
     //如果瀏覽器不支援JSON則載入json2.js
     $.getScript('../../Scripts/json2.js');
}

//后端的接口类
var implementsObj = function(){
//	this = window.external;
	var obj = null;
//	obj = (typeof(Android)!='undefined' && Android) ? Android : null;
	obj = (typeof(window.external)!='undefined' && window.external) ? window.external : null;
	
	this.jsSetCookie = function(url){
		if(obj!=null){
			obj.jsSetCookie(url);
		}
	}
	/*
	获取平台访问地址
	*/
	this.getAddress = function(){
		if(obj!=null){
			return obj.getAddress();
		}
		return '';
	}
	/*
	获取平台访问用户名
	*/
	this.getUsrName = function(){
		if(obj!=null){
			return obj.getUsrName();
		}
		return '';
	}
	/*
	获取平台访问密码
	*/
	this.getPasswd = function(){
		if(obj!=null){
			return obj.getPasswd();
		}
		return '';
	}
	
	/*
	获取数据记录
	index:下标值
	*/
	this.jsValuesGet = function(index){
		if(obj!=null){
			return obj.jsValuesGet(index);
		}
		return '';
	}
	
	
	/*
	设置数据记录
	index:下标值
	str:记录值，字符串型
	*/
	this.jsValuesSet = function(index,str){
	//	alert(index+":"+str);
		if(obj!=null){
			obj.jsValuesSet(index,str);
		}
	}
	
	
	/*
	获取用户ID
	*/
	this.getStuId = function(){
		if(obj!=null){
            //alert("getstuid");
			return obj.getStuId();
		}
		return '';
	}
	
	/*
	设置用户ID
	studentid:用户ID
	*/
	this.setStuId = function(studentid){
		if(obj!=null){
			return obj.setStuId(studentid);
		}
		return '';
	}
	
	
	/*
	网络是否连接
	默认为连接
	*/
	this.isNetworkConnect = function(){
		if(obj!=null){
			return obj.isNetworkConnect();
		}
		return true;
	}
	
	
	/*
	关闭页面加载进度显示
	用于Android系统中的页面加载
	*/
	this.closeProgress = function(){
		if(obj!=null){
			obj.closeProgress();
		}
	}
	
	/*
	开始记录日志
	json:数据内容
	type:记录类型
	*/
	this.startLog = function(json,type){
		if(obj!=null){
			obj.startLog(json,type);
		}
	}
	
	/*
	结束记录日志
	json:数据内容
	type:记录类型
	*/
	this.endLog = function(json,type){
		if(obj!=null){
			obj.endLog(json,type);
		}
	}
	
	/*
	返回关闭页面
	*/
	this.exit = function(){
		if(obj!=null){
			obj.exit();
		}
	}
	
	/*
	获取离线的总目录数据
	*/
	this.getOffline = function(){
		if(obj!=null){
			return obj.getOffline();
		}
		return '';
	}
	
	/*
	保存文件
	data:文件中保存的内容
	path:文件保存路径
	*/
	this.saveFile = function(data,path){
		if(obj!=null){
			return obj.saveFile(data,path);
		}
		return 0;
	}
	
	/*
	以HTTP方式POST请求
	url:请求地址
	id:
	data:请求参数数据
	*/
	this.httpPost = function(url,id,data){
		if(obj!=null){
			return obj.httpPost(url,id,data);
		}
		return 0;
	}
	
	/*
	离线下载课本及资源
	data:课本总目录数据
	_data:需下载的数据
	*/
	this.offlineDownload = function(data,_data){
		if(obj!=null){
			return obj.offlineDownload(data,_data);
		}
		return 0;
	}
	this.getXEdutechEntity = function(){
            //alert("obj==null");
        if(obj!=null){
            //alert("1111");
			return obj.getXEdutechEntity();
		}
		return 0;
    }
    this.getXEdutechSign = function(){
        if(obj!=null){
			return obj.getXEdutechSign();
		}
		return 0;
    }
	if(obj==null){
		return null;
	}
	return this;
}


//var Android = null;
//Android = new implementsObj(); 

var href = window.location.href;
if(href.indexOf('#&ui-state=dialog')!=-1){
	href = href.replace('#&ui-state=dialog','');
	window.location.href = href;
}

if($(window).width()>1200){
document.write('<link rel="stylesheet" href="../../css/_common.css"/>');
}

document.write('<script src="../../Scripts/loading.js"></script>');

var DEBUG = true;
DEBUG = false;

var timeout = 20000;//请求访问超时时长

var http = '',username='',pwd='',studentId=-1;
http = DEBUG ? 'http://10.10.10.28' : ((typeof(Android)!='undefined' && Android && typeof(Android.getAddress())!='undefined') ? Android.getAddress() : 'http://10.10.10.28');
username = DEBUG ? 'http://10.10.10.28' : ((typeof(Android)!='undefined' && Android && typeof(Android.getUsrName())!='undefined') ? Android.getUsrName() : '20130101');
pwd = DEBUG ? 'http://10.10.10.28' : ((typeof(Android)!='undefined' && Android && typeof(Android.getPasswd())!='undefined') ? Android.getPasswd() : '123456');
studentId = DEBUG ? -1 : ((typeof(Android)!='undefined' && Android && typeof(Android.getStuId())!='undefined') ? Android.getStuId() : -1);

if(http!="" && http.indexOf("http://")==-1){
    
	http = "http://"+http;	
}
if(typeof(Android)!='undefined' && typeof(Android.getServerUrl)!='undefined')
{
    http = Android.getServerUrl();
}
var booksImgs = ['语文','数学','化学','历史','物理','英语','地理','思想政治','政治','班会育人','科学','劳技','历史与社会','美术','生物','体育','通用','信息技术','音乐','自选','综合'];
function imgIsExist(name){
	var flag = 0;
	for(var i=0;i<booksImgs.length;i++){
		if(booksImgs[i]==name){
			flag = 1;
			break;
		}
	}
	return flag;
}

//接口定义
var defineds = {
	url:{
		base:{
			CheckUser:"/api/pad-login/code/"+username+"/pwd/"+pwd
//			,GetSubjects:"/student/fetchdata/fetch-subject"
            ,GetSubjects:"/api/subject"
//			,GetBookList:"/student/fetchdata/get-guide-learn-tbs-by-subject"
            ,GetBookList:"/api/textbook/type/book"
//			,GetChapterList:"/student/fetchdata/fetch-textbook-by-subject"
//			,GetNomBookList:"/student/fetchdata/get-textbook-by-subject"
            ,GetChapterList:"/api/textbook/type/node"
			,GetNomBookList:"/api/textbook/type/book"
		}
		//我的收藏
		,error:{
			GetErrorList:"/api/error/type/list"
			,DelError:"/student/error-info/delete-pad-error"
			,SetErrorInfo:"/student/error-info/add-error-desc"
		}
		//我的作业
		,homework:{
//			GetHomeWorkList:"/student/online-task/get-pad-task"
            GetHomeWorkList:"/api/task"  //20150122 luojie
//			,DoHomework:"/student/online-exam-pad/viewpad-do-task-student"
            ,DoHomework:"/api/task/"    //20150122 luojie
//			,SearchHomework:"/student/online-task/student-pad-look-mark"
            ,SearchHomework:"/api/task" //20150122 luojie  后续加的由examid变更为id
//			,AddError:"/student/online-task/add-pad-error"
            ,AddError:"/api/error/type/add"
//			,RemoveError:"/student/online-task/move-pad-error"
//			,ErrorHomework:"/student/error-info/delete-pad-error"
            ,RemoveError:"/api/error/type/mov"
			,ErrorHomework:"/api/error/type/mov"
//			,AskHelpHomework:"/student/online-task/request-help"
            ,AskHelpHomework:"/api/help"
		}
		//我的试卷
		,exam:{
			GetExamList:"/student/online-exam/get-pad-exam"
		//	,DoExam:"/student/online-exam-pad/do-exam-student"
			,DoExam:"/student/online-exam-pad/viewpad-do-task-student"
			,SearchExam:"/student/online-task/student-pad-look-mark"
			,AddError:"/student/online-task/add-pad-error"
			,RemoveError:"/student/online-task/move-pad-error"
			,ErrorExam:"/student/error-info/delete-pad-error"
		}
		//我的学案
		,xuean:{
			GetXueanList:"/student/course/pad-course-list"
			,GetXueanInfo:"/student/course/pad-course-detail"
		}
		//课堂记录
		,jilu:{
			GetXuanList:"/student/class-report/get-pad-report"
			,GetXuanInfo:"/student/class-report/read-pad-class-report"
		}
		//导学本
		,daoxueben:{
//			GetBookList:"/student/fetchdata/get-guide-learn-tbs-by-subject"
            GetBookList:"/api/textbook/type/book"//穆成闪——2015.3.14接口变更
			,GetBookInfo1:"/student/fetchdata/get-daoxue-by-textbook"
//			,GetBookInfo:"/student/fetchdata/get-exam-by-textbook"
			,GetBookInfo:"/api/guide-learn/type/dx"//穆成闪——2015.3.14接口变更
//			,GetExamInfo:"/student/fetchdata/get-daoxue-question"
			,GetExamInfo:"/api/guide-learn/type/exam"//穆成闪——2015.3.14接口变更
//			,SubmitExam:"/student/fetchdata/set-daoxue-question"
			,SubmitExam:"/api/guide-learn/type/exam"//穆成闪——2015.3.14接口变更
		}
		//作业辅导
		,zyfd:{
			//GetBookList:"/student/fetchdata/get-task-coach-tbs-by-subject"
			GetBookList:"/api/textbook/type/book"//穆成闪——2015.3.18接口变更
			//,GetBookInfo:"/student/fetchdata/get-taskcoach-by-textbook"//等待新接口，准备变更
			//,GetBookInfo:"/api/homework/tbid"//穆成闪——2015.3.19接口变更
			,GetBookInfo:"/api/task-coach/type/list"//穆成闪——2015.3.19接口变更
			,ControlError:"/student/fetchdata/set-task-coach-error"
		}
		//个人成长
		,grcz:{
			GetFileList:"/d-bank/get-file"
			//,GetBookInfo:"/student/fetchdata/get-taskcoach-by-textbook"
			//,GetBookInfo:"/api/homework/tbid"//穆成闪——2015.3.19接口变更
			,GetBookInfo:"/api/homework"//穆成闪——2015.3.19接口变更
			,ControlError:"/student/fetchdata/set-task-coach-error"
		}
	}
};
//页脚不消失
$.mobile.fixedtoolbar.prototype.options.tapToggle = false;

/*
checkLogin 检测是否已登录过
checkCookie = 是否检测cookie true||false
tipsId = 信息提示框ID
callback = 回调函数
*/
function checkLogin(checkCookie,tipsId,callback){
	if(typeof(Android)!="undefined"){
	//	alert("getStuId="+Android.getStuId());
		var cookie = {};
		//if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
		if(typeof(Android.jsValuesGet)!='undefined'){
			var jsValue = Android.jsValuesGet(0);
			if(jsValue!=null && jsValue!=""){
				cookie = JSON.parse(jsValue);
			}
			//cookie = JSON.parse(Android.jsValuesGet(0));
		}
//		alert("366studentId"+studentId+"  "+Android.getStuId());
	//	if((typeof(cookie["studentId"])=='undefined' || cookie["studentId"]==-1 )){
			//if((typeof(Android.getStuId)!='undefined' && (Android.getStuId()==null || Android.getStuId()==-1))){
			if(studentId==-1){
				if(typeof(Android)!='undefined' && typeof(Android.isNetworkConnect)!='undefined' && Android.isNetworkConnect==false){
					//网络不通时
					loading({text:'您尚未登录过本机，请联网登录',timer:1000});
				}
				login(function(){
					callback();
					return;
				},function(info){
					if(tipsId==''){
						loading({text:info,timer:500});
					}else{
//					showTips(tipsId,info);
                    if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                    {
                        Android.showError(info);
                    }
					loading({option:'close'});
				
					(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
					}
					return;
				});
			}
	//	}

	//alert("00");
		if(checkCookie==false){
			callback();
			return;
		}
//		alert("400:"+JSON.stringify(cookie));
		if(typeof(cookie["login"])=='undefined'
			|| (typeof(cookie["login"])!='undefined' && (http!=cookie["login"]["http"] || username!=cookie["login"]["username"] || pwd!=cookie["login"]["pwd"]))
			|| typeof(cookie["studentId"])=='undefined' || cookie["studentId"]==-1 || cookie["studentId"]!=studentId
			){
			//alert("55");
			login(function(){
				callback();
				//alert("33");
				return;
			},function(info){
				if(tipsId==''){
					loading({text:info,timer:500});
				}else{
//				showTips(tipsId,info);
//                if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
//                {
//                    Android.showError(info);
//                }
				loading({option:'close'});
			
				(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
				}
				//alert("22");
                callback();
				return;
			});
			//alert("11");
			return;
		}
		//alert("66");
		callback();
		return;
	}else{
		//alert("88");
		callback();
		return;
	}
}
//登录
function login(callback,callback2){
    if(typeof(Android)!='undefined' && typeof(Android.getServerUrl)!='undefined')
    {
        http = Android.getServerUrl();
    }
	var url = http + defineds.url.base.CheckUser;
//    alert("445:"+url);
	var login = false;
	if(login==false){
         var xentity = "";
        var xsign = "";
        if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
        {
            xentity = Android.getXEdutechEntity();
        } 
        if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
        {
            xsign = Android.getXEdutechSign();
        }
//        alert("458:"+xentity+","+xsign);
		var flag = DEBUG ? 0 : $.ajax({
			type:'get',
			url:url,
            data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
			dataType:'jsonp',
			callback:'json_callback',
			timeout:timeout,
			success:function(res){
				if(res.status==true){
					if(typeof(Android)!="undefined"){
					//	Android.jsValuesInit(1);
						var cookie = {};
						if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
							cookie = JSON.parse(Android.jsValuesGet(0));
						}
						cookie["login"] = {};
						cookie["login"]["http"] = http;
						cookie["login"]["username"] = username;
						cookie["login"]["pwd"] = pwd;
						cookie["login"]["studentId"] = res.data.studentid;
						cookie["studentId"] = res.data.studentid;
						
						if(typeof(Android.jsValuesSet)!='undefined'){
							Android.jsValuesSet(0,JSON.stringify(cookie));
						}
						if(typeof(Android.setStuId)!='undefined'){
							Android.setStuId(res.data.studentid);
						}
					}
					callback();
				}else{
//                    alert("490");
					callback2(res.errorInfo);
				}
				return res;
			},error:function(XMLHttpRequest, textStatus, errorThrown){
//				alert("ajaxGetJsonp："+errorThrown);
//				alert("ajaxGetJsonp："+textStatus);
//				alert("ajaxGetJsonp："+JSON.stringify(XMLHttpRequest));
//				alert("ajaxGetJsonp："+XMLHttpRequest);
//				var errorTips = "请求有误";
                var errorTips = "访问超时，请检查网络是否正常或配置项是否正确";
				if(textStatus == "timeout"){
					errorTips = "访问超时，请检查网络是否正常或配置项是否正确";
				}
				if(typeof(Android)!='undefined' && typeof(Android.isNetworkConnect)!='undefined' && Android.isNetworkConnect==false){
					//网络不通时
					errorTips = '网络不通，请检查网络';
				}
				callback2(null);
				return {"status":false,"errorNum":2,"errorInfo":errorTips};
			}
		});
	}
}

//查询本地数据
function ajaxGet(url,tipsId,callback){
    var xentity = "";
    var xsign = "";
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
    {
        xentity = Android.getXEdutechEntity();
    } 
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
    {
        xsign = Android.getXEdutechSign();
    }
//	checkLogin(false,tipsId,function(){
		$.ajax({
			type:'get',
			url:url,
            data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
			dataType:'text',
			success:function(res){
				if(res!=""){
					var data = JSON.parse(res);
					callback(data);
				}else{
					if(tipsId==''){
						loading({text:'请求数据有误',timer:500});
					}else{
//						showTips(tipsId,'请求数据有误');
                        if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                        {
                            Android.showError("数据请求有误");
                        }
						loading({option:'close'});
							
						(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
					}
				}
			},error:function(XMLHttpRequest, textStatus, errorThrown){
				
			/*	alert(XMLHttpRequest);
				alert(textStatus);
				alert(errorThrown);
				*/
				var errorTips = Android.getHtmlNoOfflineData();
                callback("");
				if(textStatus == "timeout"){
					errorTips = Android.getHtmlNetWorkTimeout();
				}
				if(typeof(Android)!='undefined' && typeof(Android.getStuId)!='undefined' && (Android.getStuId()==null || Android.getStuId()==-1)){
					errorTips = "您尚未登录过本机，无法查询到您的离线数据，请联网登录";
				}
				if(tipsId==''){
					loading({text:'请求数据有误',timer:500});
				}else{
//					showTips(tipsId,errorTips);
                    if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                    {
                        Android.showError(errorTips);
                    }
					loading({option:'close'});
						
					(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
				}
                ;
			}
		});
//	});
}

//跨域查询数据
function ajaxGetJsonp(url,tipsId,callback){
	if(typeof(Android)!='undefined' && typeof(Android.isNetworkConnect)!='undefined' && Android.isNetworkConnect==false){
		//网络不通时
		if(tipsId==''){
			loading({text:'网络不通，请联网后操作',timer:500});
		}else{
//			showTips(tipsId,'网络不通，请联网后操作');
            if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
            {
                Android.showError("网络不通，请联网后操作");
            }
			loading({option:'close'});
		
			(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
		}
        ;
		return;
	}
    //luojie
    var xentity = "";
    var xsign = "";
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
    {
        xentity = Android.getXEdutechEntity();
    } 
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
    {
        xsign = Android.getXEdutechSign();
    }
//    alert(xentity);
//    alert(xsign);
//	checkLogin(true,tipsId,function(){
//		 alert("url:"+url);
		$.ajax({
			type:'get',
			url:url,
//            data:{'X-Edutech-Entity':"1229201401001",'X-Edutech-Sign':"1419326544+9d52c6f59cfde90b0577b2ae63b193c2"},
			data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
			dataType:'jsonp',
            headers:{'Accept-Encoding':'gzip'},
			callback:'json_callback',
			timeout:timeout,
			success:function(res){
//				alert("ajaxGetJsonp："+JSON.stringify(res));
				//Android.put_json(JSON.stringify(res));信息打印
				if(res && res.status==false){
					if(res.errorNum==9 || res.errorInfo =='登陆超时，请重新登录！'){//超时重登录
						var _url = http + defineds.url.base.CheckUser;
					//	Android.jsSetCookie(_url);
						
						login(function(){
							ajaxGetJsonp(url,tipsId,callback);
//		 alert("1");
							return;
						},function(info){
							if(tipsId==''){
								loading({text:info,timer:500});
							}else{
//								showTips(tipsId,info);
                                if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                                {
                                    Android.showError(info);
                                }
								loading({option:'close'});
								(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
							}
//		 alert("2");
							return;
						});
					}else if(res.errorNum==1 || res.errorInfo.indexOf('未查询到任何数据信息')){
					   callback('');
                    }else{
						if(tipsId==''){
							loading({text:res.errorInfo,timer:500});
						}else{
//							showTips(tipsId,res.errorInfo);
                            if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                            {
                                Android.showError(res.errorInfo);
                            }
							loading({option:'close'});
						
							(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
						}
//		 alert("3");
						return;
					}
				}else{
//                    var errorTips = "加载成功";
//					loading({text:errorTips,timer:500});
//		 alert("4");
					callback(res);
				}
			},error:function(XMLHttpRequest, textStatus, errorThrown){
				
			    //alert(XMLHttpRequest);
				//alert(textStatus);
				//alert(errorThrown);
//				var errorTips = "加载失败了，点击重新加载"+url+",req:"+xsign+Android.getUsrName();
                var errorTips = "加载失败了，点击重新加载";
				if(textStatus == "timeout"){
//                    errorTips = "访问超时，请检查网络"+url+",error:"+errorThrown;
                    errorTips = Android.getHtmlNetWorkTimeout();
//					errorTips = "访问超时，请检查网络"+url+",req:"+XMLHttpRequest+",status:"+textStatus+",error:"+errorThrown;
                    
//		 alert("5");
				}
				if(tipsId==''){
					loading({text:errorTips,timer:5000});
//		 alert("6");
				}else{
//					showTips(tipsId,errorTips);
                    if(typeof(Android)!='undefined'&&typeof(Android.showError)!='undefined')
                    {
                        Android.showError(errorTips);
                    }
					loading({option:'close'});
						
					(typeof(Android)!='undefined' && typeof(Android.closeProgress)!='undefined') ? Android.closeProgress() : '';
//		 alert("7");
				}
                ;
			}
		});
//	});
}
/*
写日志 
type:记录类型1-12
status:状态1=开始0=停止
params:参数JSON
*/
function writeLog(type,status,params){
	var json = {};
	json["UserID"] = (studentId!=-1) ? studentId.toString() : 'NULL';//学生id
	json["Type"] = type.toString();//类型
	json["SubjectID"] = (typeof(params.subjectId)!='undefined') ? params.subjectId : 'NULL';//科目id
	json["BookID"] = (typeof(params.bookId)!='undefined') ? params.bookId : 'NULL';//课本id
	json["BookName"] = (typeof(params.bookName)!='undefined') ? params.bookName : 'NULL';//课本名id
	json["SectionsID"] = (typeof(params.sectionsId)!='undefined') ? params.sectionsId : 'NULL';//章节id数组
//	json["ChapterID"] = (typeof(params.chapterId)!='undefined') ? params.chapterId : 'NULL';//章id
//	json["PartID"] = (typeof(params.partId)!='undefined') ? params.partId : 'NULL';//节id
	json["AssetsID"] = (typeof(params.assetsId)!='undefined') ? params.assetsId : 'NULL';//资源id,作业id、试卷id、导学id、题目id、记录id
	json["AssetsName"] = (typeof(params.assetsName)!='undefined') ? params.assetsName : 'NULL';//资源名称,我的课本章名称、学案文件名
	json["VisitCount"] = (typeof(params.visit)!='undefined') ? params.visit : 'NULL';;//（1代表开始播放，0暂停开始播放）
//	alert(JSON.stringify(json));
	if(typeof(Android)!="undefined"){
		if(status == 1){
			if(typeof(Android.startLog)!="undefined"){
				Android.startLog(JSON.stringify(json),type.toString());
			}
		}else{
			if(typeof(Android.endLog)!="undefined"){
				Android.endLog(JSON.stringify(json),type.toString());
			}
		}
	}
}

//根据下标获取cookie
function getCooke(index){
	var cookie = {};
	if(typeof(Android)!='undefined' && typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(index)!=null && Android.jsValuesGet(index)!=""){
		cookie = JSON.parse(Android.jsValuesGet(index));
	}
	return cookie;
}

/*
获取JSON数据，如无数据值则以默认值返回
data = 对象
defaultV = 默认值
*/
function getDataValue(data,defaultV){
	var value = defaultV;
	if(typeof(data)!='undefined'){
		value = data;
	}
	return value;
}

//返回提示
function goExit(){
	loading({option:'close'});
//	setTimeout(function(){
	$('#popupExit').popup('open');
//	},500);
	$('#cancle').unbind('click').bind('click',function(evt){
		setTimeout(function(){
		$('#popupExit').popup('close');
		},500);
		evt.preventDefault();
		return;
	});
	
	$('#sure').unbind('click').bind('click',function(evt){
		exit();
		evt.preventDefault();
		return;
	});
}
/*
返回
*/
function exit(){
	if(typeof(Android)!='undefined' && Android){
		Android.exit();
		return;
	}
	window.location.href = "../../index.html";
}
/*
回到首页
*/
function goHome(){
	screenAlwaysLightOff();//返回课本页面关闭常亮
	if(typeof(Android)!="undefined"){
		var cookie = {};
		var onLine = false;// goHome 20140220
	//	cookie["login"] = {'http':http,'username':username,'pwd':pwd};
		if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=''){
			var _cookie = JSON.parse(Android.jsValuesGet(0));
			onLine = (typeof(_cookie["onLine"])!='undefined')?_cookie["onLine"]:false;// goHome 20140220
			if((typeof(_cookie["login"])!='undefined'))
				cookie["login"] = _cookie["login"];
			cookie["studentId"] = (typeof(_cookie["studentId"])!='undefined') ? _cookie["studentId"] : ((typeof(Android.getStuId)!='undefined')?Android.getStuId():-1);
		}else{
			cookie["studentId"] = ((typeof(Android.getStuId)!='undefined')?Android.getStuId():-1);
		}
		if(typeof(Android.jsValuesSet)!='undefined'){
			Android.jsValuesSet(0,JSON.stringify(cookie));
			Android.jsValuesSet(1,'');
			Android.jsValuesSet(2,'');
			Android.jsValuesSet(3,'');
			Android.jsValuesSet(4,'');
		}
	}
//	window.location.href = "index.html";
//window.location.href = "local.html";	//remove20140220
	//start 20140220  在线目录页面能回到在线首页
	if(onLine ==true)
		window.location.href = "index.html";
	else
		window.location.href = "local.html";	
	//end
}

//获取URL参数
function getUrlParam(name)
{
	var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
	var r = window.location.search.substr(1).match(reg);  //匹配目标参数
	if (r!=null) return unescape(r[2]); return null; //返回参数值
} 

//显示提示信息
function showTips(id,errorInfo){
	if(id==''){return;}
	//$('#'+id).html('<div style="width:200px; height:100px; border:1px solid;position:absolute;top:50%;left:50%;margin-top:-100px;margin-left:-100px;">'+errorInfo+'</div>');
	$('#'+id).show().html('<div style="width:200px; height:120px; border:0px solid #DEDEDE;position:absolute;top:50%;border-radius: 5px 5px 5px 5px;left:50%;margin-top:-60px;margin-left:-100px;box-shadow: 0px 0px 5px #333;box-shadow: 0px 0px 0px #333;"><div style="width:94px;height:62px;margin:0 auto;margin-top:10px;"><img src="../../images/loading1.gif"/></div><div style="height:38px;text-align:center;margin-top:5px;">'+errorInfo+'</div></div>');
}

//进度条初始化
function progressInit(id,value){
	var progressbar = $( "#"+id ),
	progressLabel = $( ".progress-label",$( "#"+id ) );
	progressbar.progressbar({
		value: false,
		change: function() {
			progressLabel.text( (progressbar.progressbar( "value" ) || 0) + "%" );
		},
		complete: function() {
			progressLabel.text( "完成!" );
			setTimeout(function(){
				progressbar.progressbar( "destroy" );
				progressbar.hide();
			},500);
		}
	});
	if(value){
		progressbar.progressbar( "value", value );
	}
	setTimeout( function(){
	//	progress(id);
	//	progressInit(id,value+10);
	}, 1000 );
}



/*设置children的树节点显示图片及文字显示样式
icon:是否修改标识图片
*/
function setTreeIcon(treeObj,children,icon){
	if(children){
		for(var j=0;j<children.length;j++){
			var node = children[j];
			if(node.question){
				if(node.question.length>0){
					//isdown=是否正在下载，downTotal=已下载完成的
					var isdown = false,downTotal = 0,isnew = false;
					for(var m = 0;m<node.question.length;m++){
						var question = node.question[m];
						if(question.isdown && question.isdown==true){
							if(question.questionprogress && parseInt(question.questionprogress,10)==100){
								downTotal++;
							}else{
								isdown = true;
							}
						}
						if(question.isnew && (parseInt(question.isnew,10)==1 || question.isnew == true)){
							isnew = true;
						}
					}
					if(typeof(icon)!='undefined' && icon == true){
						if(isdown==true){//正在下载
							node.iconSkin = 'icon12';
							(typeof(isReload)!='undefined') ? isReload = true : '';
						}else{
							if(downTotal==0){//未下载过
								node.iconSkin = 'icon10-1';
							}else if(downTotal==node.question.length){//下载完全
								node.iconSkin = 'icon10';
								if(isnew==true){
									node.iconSkin = 'icon14-1';
								}
							}else{//仍有题目可下载
								node.iconSkin = 'icon13';
								if(isnew==true){
									node.iconSkin = 'icon14-2';
								}
							}
						}
						if(treeObj!=null){
							treeObj.updateNode(node);
						}
					}
				}else if(typeof(node.children)=='undefined'){
					if(typeof(icon)!='undefined' && icon == true){
						if(node.iconSkin != 'icon0'){
							node.iconSkin = 'icon11-1';
							node.iconSkin = 'icon0';
						}
					}
					node.font = {'color':'#cacaca'};
					if(treeObj!=null){
						treeObj.updateNode(node);
					}
				}
			}
			else if(typeof(node.webpath)=='undefined' || (node.webpath && (node.webpath.length==0 || node.webpath[0]==""))){
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin != 'icon0'){
						node.iconSkin = 'icon11-1';
						node.iconSkin = 'icon0';
						node.iconSkin = ''; //kao 20140108 增加节点前面错误图标
					}
				}
				node.font = {'color':'#cacaca'};
				if(treeObj!=null){
					treeObj.updateNode(node);
				}
			}
			else if(typeof(node.isdown)=='undefined' || node.isdown==false){
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin!='icon10-1'){
						node.iconSkin = 'icon10-1';
						if(treeObj!=null){
							treeObj.updateNode(node);
						}
					}
				}
			}else if(typeof(node.isdown)!='undefined' && node.isdown==true){
				if(typeof(node.progress[0])!='undefined' && parseInt(node.progress[0],10)==100){
					if(typeof(icon)!='undefined' && icon == true){
						if(node.iconSkin!='icon10'){
							if(node.isnew && (parseInt(node.isnew,10)==1 || node.isnew==true)){
								node.iconSkin = 'icon14-1';
								if(treeObj!=null){
									treeObj.updateNode(node);
								}
							}else{
								node.iconSkin = 'icon10';
								if(treeObj!=null){
									treeObj.updateNode(node);
								}
							}
						}
					}
			//	}else if(temp.webpath && temp.webpath.length>0 && temp.webpath[0]=="" && typeof(temp.progress[0])!='undefined' && parseInt(temp.progress[0],10)<100){
				}else{
					if(typeof(icon)!='undefined' && icon == true){
						if(node.iconSkin != 'icon12'){
							node.iconSkin = 'icon12';
							if(treeObj!=null){
								treeObj.updateNode(node);
							}
							(typeof(isReload)!='undefined') ? isReload = true : '';
						}
					}
				}
			}else{
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin != 'icon0'){
						node.iconSkin = 'icon11-1';
						node.iconSkin = 'icon0';
					}
				}
				node.font = {'color':'#cacaca'};
				if(treeObj!=null){
					treeObj.updateNode(node);
				}
			}
			if(node.children){
				node.children = setTreeIcon(treeObj,node.children,icon);
			}
		}//for(var j=0;j<children.length;j++){
	}//if(children){
	return children;
}

/*设置children的树节点显示图片及文字显示样式
icon:是否修改标识图片
	只适用新的导学本
*/
function setTreeIconDao(treeObj,children,icon,pNode){
	if(children){
		for(var j=0;j<children.length;j++){
			var node = children[j];
			if(node.question){
				if(node.question.length>0){
					//isdown=是否正在下载，downTotal=已下载完成的
					var isdown = false,downTotal = 0,isnew = false;
					for(var m = 0;m<node.question.length;m++){
						var question = node.question[m];
						if(question.isdown && question.isdown==true){
							if(question.questionprogress && parseInt(question.questionprogress,10)==100){
								downTotal++;
							}else{
								isdown = true;
							}
						}
						if(question.isnew && (parseInt(question.isnew,10)==1 || question.isnew == true)){
							isnew = true;
						}
					}
					if(typeof(icon)!='undefined' && icon == true){
						if(isdown==true){//正在下载
							node.iconSkin = 'icon12';
							(typeof(isReload)!='undefined') ? isReload = true : '';
						}else{
							if(downTotal==0){//未下载过
								node.iconSkin = 'icon10-1';
							}else if(downTotal==node.question.length){//下载完全
								node.iconSkin = 'icon10';
								if(isnew==true){
									node.iconSkin = 'icon14-1';
								}
							}else{//仍有题目可下载
								node.iconSkin = 'icon13';
								if(isnew==true){
									node.iconSkin = 'icon14-2';
								}
							}
						}
						if(treeObj!=null){
							treeObj.updateNode(node);
						}
					}
				}else if(typeof(node.children)=='undefined'){
					if(typeof(icon)!='undefined' && icon == true){
						if(node.iconSkin != 'icon0'){
							node.iconSkin = 'icon11-1';
							node.iconSkin = 'icon0';
						}
					}
					node.font = {'color':'#cacaca'};
					if(treeObj!=null){
						treeObj.updateNode(node);
					}
				}
			}
			else if(typeof(node.dxitems)=='undefined' || (node.dxitems && (node.dxitems.length==0))){
				
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin != 'icon0'){
						node.iconSkin = 'icon11-1';
						node.iconSkin = 'icon0';
						node.iconSkin = ''; //kao 20140108 增加节点前面错误图标
					}
				}
                if(typeof(node.children)=='undefined'){
                    node.font = {'color':'#cacaca'};
			}
				
				if(treeObj!=null){
					treeObj.updateNode(node);
				}
			}
			else if(typeof(node.dxitems)!='undefined' && (node.dxitems && (node.dxitems.length>0))){
				//var isDownCount = 0;//节点上未下载的资源个数（包括测试 一个测试算一个）
				//var resourceCount = 0;//有资源的个数 （资源个数、测试个数）
				var unDownCount = 0;//未下载过dxid的个数
				var isDown = false;//节点上是否有下载过
				var isnew = false;//节点上有资源需要更新
				var isInDown = false;//节点上有资源正在下载
				var len = node.dxitems.length;
				for(var i=0;i<len;i++){
					var file = node.dxitems[i];
					if(typeof(file.isdown)=='undefined' || file.isdown==false){//未缓存dxid
						unDownCount ++;//该节点有资源未缓存过
					}else{//已缓存dxid
						isDown = true;//该节点有资源缓存过
						if((typeof(file.progress[0])!='undefined' && parseInt(file.progress[0],10)==100) &&
							(typeof(file.examsprogress)!='undefined' && parseInt(file.examsprogress,10)==100)){//这个dxid资源有完成离线
							 
							
						}else{
							isInDown = true;//有资源正在下载
						}
					}
				}
				//是否更新
				if(typeof(node.isnew)=='undefined' || node.isnew==false){
					isnew = false;
				}else{
					isnew = true;
				}
				//更改图标
				if(typeof(icon)!='undefined' && icon == true){
					if(isDown == false){//该节点资源都未离线过
						if(node.iconSkin!='icon10-1'){
							node.iconSkin = 'icon10-1';
						}
						if(treeObj!=null){
							treeObj.updateNode(node);
						}
					}else{//该节点资源有离线过
						if(isInDown == false){//没有资源正在下载
							if(unDownCount>0){//部分资源离线完成
								if(node.iconSkin != 'icon13'){
									node.iconSkin = 'icon13';
									if(isnew==true){
										node.iconSkin = 'icon14-2';
									}
									if(treeObj!=null){
										treeObj.updateNode(node);
									}
								}
							}else{//全部资源离线完成
								if(node.iconSkin != 'icon10'){
									node.iconSkin = 'icon10';
									if(isnew==true){
										node.iconSkin = 'icon14-1';
									}
									if(treeObj!=null){
										treeObj.updateNode(node);
									}
								}
							}
						
						}else{//有资源正在下载
							if(node.iconSkin != 'icon12'){
								node.iconSkin = 'icon12';
							}
							if(treeObj!=null){
								treeObj.updateNode(node);
							}
						}
					}
				}
			}else if(typeof(node.isdown)!='undefined' && node.isdown==true){
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin!='icon10-1'){
						node.iconSkin = 'icon10-1';
						if(treeObj!=null){
							treeObj.updateNode(node);
						}
					}
				}
			}else{
				if(typeof(icon)!='undefined' && icon == true){
					if(node.iconSkin != 'icon0'){
						node.iconSkin = 'icon11-1';
						node.iconSkin = 'icon0';
					}
				}
				node.font = {'color':'#cacaca'};
				if(treeObj!=null){
					treeObj.updateNode(node);
				}
			}
			if(typeof(pNode)!='undefined' && typeof(node.dxitems)!='undefined' || (node.dxitems && (node.dxitems.length>0))){
				pNode.font = {};
				if(treeObj!=null){
					treeObj.updateNode(pNode);
				}
			}
			if(node.children){
				node.children = setTreeIconDao(treeObj,node.children,icon,node);
			}
		}//for(var j=0;j<children.length;j++){
	}//if(children){
	return children;
}


// 1_2_3  转  id children 递归
function getDownTree(nodearr,i,data,json){
	if(typeof(nodearr)!='undefined' && typeof(i)!='undefined'&&typeof(data)!='undefined'&& typeof(json.id)!='undefined'){
		
		//console.log(JSON.stringify(json));
		if(i<nodearr.length){
			var id = {"id":nodearr[i]};
			if(i+1 ==nodearr.length){
				if(data.dxid != 'undefined' && data.dxid !=null && data.dxid !=""){//新导学本单个资源下载
					id['dxid'] = data.dxid;
				}else{
					id['data'] = [];
					id['data'].push(data);
				}
				json['children'] = [];
				json['children'].push(id);
			}else{
				var leaf = getDownTree(nodearr,i+1,data,id);
				json['children'] = [];
				json['children'].push(leaf);
			}
			//console.log(i+"=="+JSON.stringify(json));
		}	
	}
	return json;
}

//获取被下载节点的结构数组
function getDownArray(array,json,splitS){
	if(typeof(json)!='undefined' && typeof(json.id)!='undefined'){
		var temp = '';
		if(array!=""){temp=(typeof(splitS)!='undefined') ? splitS : ',';};
		array = array + temp + json.id;
		if(typeof(json.items)!='undefined' && json.items.length>0){
			array = getDownArray(array,json.items[0],splitS);
		}
		//kao 20140108  我的收藏 加载节点下载的数据 json 是children
		if(typeof(json.children)!='undefined' && json.children.length>0){
			array = getDownArray(array,json.children[0],splitS);
		}
	}
	return array;
}
//获取被下载节点的结构JSON
function getDownJson(json,node){
	if(typeof(node.getParentNode)!="undefined"){
		var pNode = node.getParentNode();
		if(pNode!=null){
			var _json = {"id":pNode.id};
			_json['children']=[];
			_json['children'].push(json);
			_json = getDownJson(_json,pNode);//20131129
			json = _json;
		}
	}
	return json;
}
//获取被下载节点的结构JSON
function getbeforeNode(nodelist,node){
	if(typeof(node.getParentNode)!="undefined"){
		var pNode = node.getParentNode();
		if(pNode!=null){
			//console.log("pNode.id = "+pNode.id);
			nodelist.unshift(pNode.id);
			nodelist = getbeforeNode(nodelist,pNode);//20131129
		}
	}
	return nodelist;
}
/*题目webpath 中存在数组  生成temp path 数组*/
	function appendTempPath(path){
		var newPath ;
		if($.isArray(path)){
			newPath = [];
			for(var i=0;i<path.length;i++){
				var tempPath = 'temp/'+path[i];//default.json
				if(path[i].lastIndexOf("\/")!=-1){
					tempPath = 'temp/'+path[i].substring(path[i].lastIndexOf("\/")+1);
				}
				newPath.push(tempPath);
			}
			
		}else{
			newPath = 'temp/'+path;//default.json
			if(path.lastIndexOf("\/")!=-1){
				newPath = 'temp/'+path.substring(path.lastIndexOf("\/")+1);
			}
		}
		return newPath;
	}		
/*右侧弹出层 start*/		
	
var _dataObj = !DEBUG ? {} : {
	"status":true,
	"errorNum":0,
	"errorInfo":"" ,  
	"data":{
		"subject":[
				{"id":"1","name":"语文"}
				,{"id":"2","name":"数学"}
				,{"id":"3","name":"英语"}
				,{"id":"4","name":"物理"}
				,{"id":"5","name":"化学"}
				,{"id":"6","name":"历史"}
				,{"id":"7","name":"地理"}
				,{"id":"8","name":"历史"}
				,{"id":"9","name":"生物"}
				,{"id":"10","name":"政治"}
				] 
		,"term":[
				{"id":"1","name":"上学期"}
				,{"id":"2","name":"下学期"}
				]
		,"chapter":{
				"items":[
						{"id":"1","name":"第一单元","items":[
														/*	{"id":"2","name":"1.1在山的那边","items":[
																	{"id":"3","name":"节名称"}
																	]
															}*/
															{"id":"2","name":"1.1在山的那边"}
															,{"id":"3","name":"1.2走一步，再走一步"}
															,{"id":"4","name":"1.3生命，生命"}
															,{"id":"4","name":"1.4藤萝瀑布"}
															,{"id":"4","name":"1.5童趣"}
															,{"id":"4","name":"1.6第一单元测试"}
															]
						}
						,{"id":"1","name":"第二单元","items":[
															{"id":"2","name":"1.1在山的那边"}
															,{"id":"3","name":"1.2走一步，再走一步"}
															,{"id":"4","name":"1.3生命，生命"}
															,{"id":"4","name":"1.4藤萝瀑布"}
															,{"id":"4","name":"1.5童趣"}
															,{"id":"4","name":"1.6第一单元测试"}
															]
						}
						]
				}
	}
};

//选章节查看相应列表
function getBookList(subjectId,termId,callback){
//	alert(termId+","+subjectId+","+chapterId+",");
	//AJAX请求获取dataObj数据
	var url = http + defineds.url.base.GetNomBookList;
	url += "/subjectid/"+subjectId;
	if(termId!=null && termId!=-1){
		url += "/termid/"+termId;
	}
	//console.log("getBookList url="+url);
	var dataObj = null;
    var xentity = "";
    var xsign = "";
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
    {
        xentity = Android.getXEdutechEntity();
    } 
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
    {
        xsign = Android.getXEdutechSign();
    }
	var flag = DEBUG ? loadChapterHtml(_dataObj) : $.ajax({
		type:'get',
		url:url,
        data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
		dataType:'jsonp',
		callback:'json_callback',
		success:function(res){
			if(typeof(callback)!='undefined'){
				callback(res);
			}else{
				//loadChapterHtml(res);
			}
            
		},error:function(){
		//	$('#content').html('<div style="width:200px; height:100px; border:1px solid;position:absolute;top:50%;left:50%;margin-top:-100px;margin-left:-100px;">加载失败了，点击重新加载</div>');
            ;
		}
	});
}

//选章节查看相应列表
function showChapter(subjectId,termId,bookId,callback){
	//获取书本列表后获取章节信息
    if(typeof(Android)!='undefined' && typeof(Android.getServerUrl)!='undefined')
    {
        http = Android.getServerUrl();
    }
	getBookList(subjectId,termId,function(dataObj){
		var _booklist = {};
		_booklist = (typeof(dataObj.data) != 'undefined' && dataObj.data) ? dataObj.data : {};
	//	alert(termId+","+subjectId+","+chapterId+",");
		//AJAX请求获取dataObj数据
		var url = http + defineds.url.base.GetChapterList;
		url += "/subjectid/"+subjectId;
		if(termId!=null && termId!=-1){
			url += "/termid/"+termId;
		}
		if(bookId!=null && bookId!=-1){
			url += "/tbid/"+bookId;
		}
		//console.log("url="+url);
		var dataObj = null;
         var xentity = "";
        var xsign = "";
        if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
        {
            xentity = Android.getXEdutechEntity();
        } 
        if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
        {
            xsign = Android.getXEdutechSign();
        }
		var flag = DEBUG ? loadChapterHtml(_dataObj) : $.ajax({
			type:'get',
			url:url,
            data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
			dataType:'jsonp',
			callback:'json_callback',
			success:function(res){
				res['data'].book = _booklist;
				if(typeof(callback)!='undefined'){
					callback(res);
				}else{
					loadChapterHtml(res);
				}
			},error:function(){
			//	$('#content').html('<div style="width:200px; height:100px; border:1px solid;position:absolute;top:50%;left:50%;margin-top:-100px;margin-left:-100px;">加载失败了，点击重新加载</div>');
                ;
			}
		});
	});
}

//选章节查看相应列表
function showChapter_old(subjectId,termId,bookId,callback){
//	alert(termId+","+subjectId+","+chapterId+",");
	//AJAX请求获取dataObj数据
	var url = http + defineds.url.base.GetChapterList;
	url += "/subjectid/"+subjectId;
	if(termId!=null && termId!=-1){
		url += "/termid/"+termId;
	}
	if(bookId!=null && bookId!=-1){
		url += "/tbid/"+bookId;
	}
	//console.log("url="+url);
	var dataObj = null;
     var xentity = "";
    var xsign = "";
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechEntity)!='undefined')
    {
        xentity = Android.getXEdutechEntity();
    } 
    if(typeof(Android)!='undefined' && typeof(Android.getXEdutechSign)!='undefined')
    {
        xsign = Android.getXEdutechSign();
    }
	var flag = DEBUG ? loadChapterHtml(_dataObj) : $.ajax({
		type:'get',
		url:url,
        data:{'X-Edutech-Entity':xentity,'X-Edutech-Sign':xsign},
		dataType:'jsonp',
		callback:'json_callback',
		success:function(res){
			if(typeof(callback)!='undefined'){
				callback(res);
			}else{
				loadChapterHtml(res);
			}
		},error:function(){
		//	$('#content').html('<div style="width:200px; height:100px; border:1px solid;position:absolute;top:50%;left:50%;margin-top:-100px;margin-left:-100px;">加载失败了，点击重新加载</div>');
            ;
		}
	});
}
function loadChapterHtml(dataObj){
			$('.list_panel').hide();
		//	$('#termList').hide();
		//	$('#subjectList').hide();
		//	$('#chapterList').hide();
			if(dataObj){
			//	if(dataObj.status == "True" || dataObj.status == true){
				if(typeof(dataObj.data) != "undefined" && dataObj.data){
					if(dataObj.data.term){
						var html = '';
						for(var i=0;i<dataObj.data.term.length;i++){
							var obj = dataObj.data.term[i];
							if(termId == obj.id){
								html += '<li value="'+obj.id+'" class="selected">'+obj.name+'</li>';
							}
							else{
								html += '<li value="'+obj.id+'">'+obj.name+'</li>';
							}
						}
						$('#termList').html(html).parent().show();
					}
					if(dataObj.data.subject){
						var html = '';
						if(parseInt(subjectId,10) == 0){
						html += '<li value="0" class="selected">全部</li>';
						}else{
						html += '<li value="0">全部</li>';
						}
						for(var i=0;i<dataObj.data.subject.length;i++){
							var obj = dataObj.data.subject[i];
							if(subjectId == obj.id){
								html += '<li value="'+obj.id+'" class="selected">'+obj.name+'</li>';
							}
							else{
								html += '<li value="'+obj.id+'">'+obj.name+'</li>';
							}
						}
						$('#subjectList').html(html).parent().show();
					}
					if(dataObj.data.book){
						var html = '';
						if(dataObj.data.chapter){//有章节显示时书本可有全部项
							if(parseInt(dataObj.data.textbook.id,10)<1){
								html += '<li value="0" class="selected">全部</li>';
							}else{
								html += '<li value="0">全部</li>';
							}
						}
						if(typeof(dataObj.data.book) != 'undefined' && typeof(dataObj.data.book) != 'undefined'){
							if(subjectId == dataObj.data.book.id){
								var booklist = dataObj.data.book.data;
								for(var i=0;i<booklist.length;i++){
									var obj = booklist[i];
									if(parseInt(dataObj.data.textbook.id,10) == obj.id){
										html += '<li value="'+obj.id+'" class="selected">'+obj.name+'</li>';
									}
									else{
										html += '<li value="'+obj.id+'">'+obj.name+'</li>';
									}
								}
							}
						}
						if(!(typeof(hideBook_Chap) != 'undefined' && hideBook_Chap == 1))// hideBook_Chap == 1  不显示   
							$('#bookList').html(html).parent().show();
					}
					if(dataObj.data.chapter){
						var html = '';
						//if(parseInt(chapterId,10) == 0){||(typeof(_nodecode)!= 'undefined' && (_nodecode==null ||(_nodecode!=null && _nodecode == ""))
						if(typeof(_nodecode)== 'undefined' || (typeof(_nodecode)!= 'undefined'  &&  (_nodecode==null || (_nodecode!=null && _nodecode == "")))){
						html += '<li value="0" class="selected">全部</li>';
						}else{
						html += '<li value="0">全部</li>';
						}
						/*if(partId!=null && partId!=0){
							chapterId = chapterId+","+partId;
						}*/
						if(typeof(_nodecode)!= 'undefined' && _nodecode!=null && _nodecode!=""){
							_nodecode = (typeof(_nodecode)!='undefined') ? _nodecode.replaceAll("_",",") : '';
						}
						if(typeof(_nodecode) == 'undefined')
							html += getChapterHtml(dataObj.data.chapter,"","","");
						else
							html += getChapterHtml(dataObj.data.chapter,_nodecode,"","");
						//html += getChapterHtml(dataObj.data.chapter,chapterId,"","");
						if(!(typeof(hideBook_Chap) != 'undefined' && hideBook_Chap == 1))// hideBook_Chap == 1  不显示   
							$('#chapterList').html(html).parent().show();
					}
				}
			}
		
			$('#popupPanel').popup('open');
			
			var h = $( window ).height();
			h = h - $('#popupPanel h3').height();
			$('#popupPanel ul').each(function(){
				$(this).height(h);
			});
			
			//绑定选中科目、章节查询事件
			$('li').bind('click',function(){					  
				$('.selected',$(this).parent()).removeClass('selected');
				$(this).addClass('selected');
				var chilkUlId = $(this).parent().attr('id');
				var _termId = $('.selected',$('#termList').parent()).attr('value');
				var _subjectId = $('.selected',$('#subjectList').parent()).attr('value');
				var _bookId = $('.selected',$('#bookList').parent()).attr('value');
				var _chapterId = $('.selected',$('#chapterList').parent()).attr('value');
				subjectname = $('.selected',$('#subjectList').parent()).text();
				subjectNameToCookie(subjectname);//
				_chapterId = (typeof(_chapterId)!='undefined') ? _chapterId.replaceAll(",","_") : '';
				//var _nodecode = $('.selected',$('#chapterList').parent()).attr('value');
			/*	var _partId = 0;
				if(parseInt(_termId,10)!=parseInt(termId,10) || parseInt(_subjectId,10)!= parseInt(subjectId,10)){
					_chapterId = 0;
				}
				if(typeof(_chapterId)!='undefined' && _chapterId!=0 && _chapterId.indexOf(',')!=-1){
					_partId = _chapterId.split(',')[1];
					_chapterId = _chapterId.split(',')[0];
				}*/
			//	alert(_termId+","+_subjectId+","+_chapterId+","+_partId);
				
				$('#popupPanel').popup('close');
				setTimeout(function(){
					var url = 'subject-list.html?sid='+_subjectId;
					if(typeof(chilkUlId) != 'undefined'){
						
						if(chilkUlId == "subjectList" || chilkUlId == "termList"){
							url = 'subject-list.html?sid='+_subjectId;
						}else if(chilkUlId == "bookList"){
							url = 'subject-list.html?sid='+_subjectId+'&tbid='+_bookId;
						}else if(chilkUlId == "chapterList"){
							url = 'subject-list.html?sid='+_subjectId+'&tbid='+_bookId+'&nodecode='+_chapterId;
						}
					}
					if(typeof(_termId) !='undefined' && _termId!=null && _termId!=-1){
						url += '&tid='+_termId;
					}
					url += '&flag=1';
					/*if(typeof(_subjectId) != 'undefened' && typeof(_termId) != 'undefined' && typeof(_bookId) != 'undefined'){
				//	$.mobile.changePage('subject-list.html', { transition: "slide" });//fade slide slideup pop flip
					//点击的 ul id    $(this).parent().attr('id')
						url = 'subject-list.html?sid='+_subjectId+'&tid='+_termId+'&flag=1';
						if(_bookId!=""){
							url += '&tbid='+_bookId;
						}
						if(_chapterId!=""){
							url += '&nodecode='+_chapterId;
						}
					}
					else{
						url = 'subject-list.html?sid='+sid+'&tid='+termId+'&tbid='+tbid+'&flag=1';
					}*/
					window.location.href = url;
				},500);
			});
}

function subjectNameToCookie(_subjectname){
	
	if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet(0))!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["subjectName"] = _subjectname;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
}
function bookNameToCookie(_subjectname){
	
	if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet(0))!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["sbookName"] = _subjectname;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
}
function getSubjectNameFormCookie(){
	var _subName = "";
	if(typeof(Android)!="undefined"){
			
		var cookie = {};
		if(Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
			cookie = JSON.parse(Android.jsValuesGet(0));
		}	
		if(cookie["subjectName"]){	
			_subName = cookie["subjectName"];
			//$('#headerTitle').html(labelTitle+subjectName);
		}else{
			//$('#headerTitle').html(labelTitle.replace('—',''));
		}
	}
	return _subName;
}
//用于获取章节的HTML
function getChapterHtml(_obj,selectId,temp,parent){
	var html = '';
	for(var i=0;i<_obj.items.length;i++){
		var obj = _obj.items[i];
		var pId = parent;
		if(pId!=""){
			pId += ",";
		}
		pId += obj.id;
		if(selectId == pId){
			html += '<li value="'+pId+'" class="selected">'+temp+obj.name+'</li>';
		}
		else{
			html += '<li value="'+pId+'">'+temp+obj.name+'</li>';
		}
		if(obj.items && obj.items.length>0){
			html += getChapterHtml(obj,selectId,temp+"&nbsp;&nbsp;",pId);
		}
	}
	return html;
}
//视屏播放过程中常亮 20140417
function screenAlwaysLightOn(){//视屏播放屏幕常亮
	(typeof(Android)!='undefined' && typeof(Android.jsScreenAlwaysLightOn)!='undefined') ? Android.jsScreenAlwaysLightOn() : '';
}
//视频播放中止，关闭屏幕常亮 20140417
function screenAlwaysLightOff(){
	(typeof(Android)!='undefined' && typeof(Android.jsScreenAlwaysLightOff)!='undefined') ? Android.jsScreenAlwaysLightOff() : '';
}
//视频播放中止，关闭屏幕常亮 20140417
function getLoadingTime(toleft){
	var time = setTimeout(function(){
					loading({text:Android.getHtmlResourcesLoading(),left:toleft});
				},3000);
	return time;
}
//视频播放中止，关闭屏幕常亮 20140417
function clearLoadingTime(cleartime){
	if(cleartime !=null){
		clearTimeout(cleartime);
		cleartime = null;
	}
}
/*右侧弹出层 end*/	

String.prototype.replaceAll = function(reallyDo, replaceWith, ignoreCase) {  
    if (!RegExp.prototype.isPrototypeOf(reallyDo)) {  
        return this.replace(new RegExp(reallyDo, (ignoreCase ? "gi": "g")), replaceWith);  
    } else {  
        return this.replace(reallyDo, replaceWith);  
    }  
}  