// JavaScript Document

document.write('<style>#loading { position:fixed!important; *position:absolute; z-index:99999; left:50%; margin-left:-120px; top:50%; border-radius:5px; margin-top:-15px; padding:8px 12px 8px 28px; background:#000 url(../../images/loading.gif) no-repeat 12px center; color:#fff; font-size:12px; display:none;text-shadow:0 0 0;}</style>');
/*document.write('<style>#loading { position:fixed!important; *position:absolute; z-index:99999; left:50%; margin-left:-120px; top:50%; border-radius:5px; margin-top:-60px; padding:8px 32px 8px 88px; background:#dedede url(../../images/loading2.gif) no-repeat 12px center; color:#000; font-size:12px; display:none;text-shadow:0 0 0;height:100px;line-height:100px;font-size:18px;}</style>');*/
//显示loading信息
function loading(o)
{
	if (typeof(o) != 'object' && typeof(o) != 'string') return;
	if (typeof(o) == 'string') o = {text:o, option:'open', timer:0, mask:false};
	
	//创建蒙板层
	if(o.mask)
	{
		if (!$('#maskmodal').get(0))
		{
			$('body').prepend('<div id="maskmodal">&nbsp;</div>');
		}
		$('#maskmodal').css('display', 'block');
	}
	
	//创建信息层
	var layer = $('#loading');
	if (!layer.get(0))
	{
		$('body').prepend('<div id="loading">'+o.text+'</div>');
		layer = $('#loading');
	}
	else
	{
		layer.html(o.text);
	}	
	
	//执行动作
	switch (o.option)
	{
		case 'open':
		default:
			layer.css('margin-left',-((layer.width()+40)/2)+((typeof(o.left)!='undefined') ? parseInt(o.left,10) : 0));
			layer.fadeIn(300);
			if (o.timer)
			{
				window.setTimeout(function(){$('#loading').fadeOut(300);$('#maskmodal').css('display','none');}, o.timer);
			}
			break;
		case 'close':
			window.setTimeout(function(){$('#loading').fadeOut(300);$('#maskmodal').css('display','none');}, 500);
			break;
	}
}