// JavaScript Document
var labelTitle = '错题集—';

//2014.10.27新增函数
//全部缓存提示
function allCache(){
	loading({option:'close'});
//	setTimeout(function(){
	$('#allCache').popup('open');
//	},500);
	$('#cancle').unbind('click').bind('click',function(evt){
		setTimeout(function(){
		$('#allCache').popup('close');
		},500);
		evt.preventDefault();
		return;
	});
	
	$('#sure').unbind('click').bind('click',function(evt){
		$('#allCache').popup('close');
		//alert("前往缓存--allCache");
		javascript:downloadBook();
		evt.preventDefault();
		return;
	});
}
//2014.10.27新增函数
//全部缓存提示
function allCache_flag(flag){
	loading({option:'close'});
//	setTimeout(function(){
	$('#allCache').popup('open');
//	},500);
	$('#cancle').unbind('click').bind('click',function(evt){
		setTimeout(function(){
		$('#allCache').popup('close');
		},500);
		evt.preventDefault();
		return;
	});
	
	$('#sure').unbind('click').bind('click',function(evt){
		$('#allCache').popup('close');
		//alert("前往缓存--allCache_flag");
		javascript:downloadBook(flag);
		evt.preventDefault();
		return;
	});
}

/*
查看科目对应书籍
flag:1=远程，2=本地
id:科目ID
other:其它数据
*/
function showBooks(flag,id,other){
	if(flag==1){
	window.location.href = "books.html?parent=index.html&sid="+id;
//	window.location.href = "remote-info.html?parent=index.html";
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "index.html";
			cookie["subjectId"] = id;
			cookie["filter"] = null;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		//	Android.jsValuesSet(0,'{"goback":"index.html","subjectId":"'+id+'","filter":null}');
			
		}
	}
	else if(flag==2){
	window.location.href = "local-info.html?path="+escape(other);
	}
	else if(flag==3){
	window.location.href = "books.html?parent=history.html&sid="+id+"&filter=1";
//	window.location.href = "remote-info.html?parent=history.html";
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "history.html";
			cookie["subjectId"] = id;
			cookie["filter"] = 1;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		//	Android.jsValuesSet(0,'{"goback":"history.html","subjectId":"'+id+'","filter":1}');
		}
	}
}
/*
查看内容
flag:1=远程，2=本地
id:书籍ID
other:其它数据
*/
function showBook(flag,id,other,subjectId){
	if(flag==1){
        //alert("id:"+id+"subjectId:"+subjectId);
	window.location.href = "remote-info.html?id="+id+"&sid="+subjectId;
			if(typeof(Android)!="undefined"){
				var cookie = {};
				if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
					cookie = JSON.parse(Android.jsValuesGet(0));
				}
				cookie["bookid"] = id;
				Android.jsValuesSet(0,JSON.stringify(cookie));
			//	alert(Android.jsValuesGet(0));
			}
	}
	else if(flag==2){
	window.location.href = "local-info.html?path="+escape(other);
	}
	else if(flag==3){
	window.location.href = "remote-info.html?id="+id+"&sid="+subjectId;
			if(typeof(Android)!="undefined"){
				var cookie = {};
				if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
					cookie = JSON.parse(Android.jsValuesGet(0));
				}
				cookie["bookid"] = id;
				Android.jsValuesSet(0,JSON.stringify(cookie));
			//	alert(Android.jsValuesGet(0));
			}
	}
}


//获取被下载节点的结构数组
function getDownArray(array,json){
	if(typeof(json)!='undefined' && typeof(json.id)!='undefined'){
		var temp = '';
		if(array!=""){temp=','};
		array = array + temp + json.id;
		if(typeof(json.items)!='undefined' && json.items.length>0){
			array = getDownArray(array,json.items[0]);
		}
	}
	return array;
}
/*
播放视频写日志 
status:状态1=开始0=停止
isLocal:是否本地true,false
*/
var isPlay = 0;//是否播放中
function writeLogPlayer(status,isLocal,isNew){
	isPlay = status;
	var cookie = getCooke(0);
	var params = {};
	params.subjectId = (isLocal==true) ? 'NULL' : getDataValue(cookie['subjectId'],'NULL');//科目id
	params.bookId = (isLocal==true) ? getDataValue(jsonData.id,'NULL') : getDataValue(jsonData.data.id,'NULL');//课本id
	params.bookName = (isLocal==true) ? getDataValue(jsonData.name,'NULL') : getDataValue(jsonData.data.name,'NULL');//课本名id
	var array = (questions[_questionIndex]) ? getDownArray('',questions[_questionIndex].test).split(",") : [];
	if(array.length>0){
		array.pop();
	}
	params.sectionsId = array;//章节id数组
	
//	params.chapterId = (_treeNode && _treeNode.getParentNode()) ? _treeNode.getParentNode().id : 'NULL';//章id
//	params.partId = (_treeNode) ? _treeNode.id : 'NULL';//节id
	params.assetsId = (questions[_questionIndex]) ? getDataValue(questions[_questionIndex].id,'NULL') : 'NULL';//资源id,作业id、试卷id、导学id、题目id、记录id
	params.assetsName = (questions[_questionIndex]) ? getDataValue(questions[_questionIndex].name,'NULL') : 'NULL';//资源名称,我的课本章名称、学案文件
	params.visit = getDataValue(isNew,'0');//是否新的访问
	
	writeLog(3,status,params);
}
