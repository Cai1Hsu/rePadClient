// JavaScript Document
var labelTitle = '我的收藏—';
/*
查看科目对应书籍
flag:1=远程，2=本地
id:科目ID
other:其它数据
*/
function showBooks(flag,id,other){
//    alert("path");
	if(flag==1){
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "index.html";
			cookie["subjectId"] = id;
			cookie["filter"] = null;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
		window.location.href = "books.html?parent=index.html&sid="+id;
	}
	else if(flag==2){
        other = "../../DaoXueBen/"+other.substring(3,other.length);
		window.location.href = "local-subject-list.html?path="+escape(other);
	}
	else if(flag==3){
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "history.html";
			cookie["subjectId"] = id;
			cookie["filter"] = 1;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
		window.location.href = "books.html?parent=history.html&sid="+id;
	}
}
/*
查看内容
flag:1=远程，2=本地
id:书籍ID
other:其它数据
*/
function showBook(flag,id,other){
	var sid = -1;
	if(flag==1){
		if(typeof(Android)!="undefined"){
			var cookie = JSON.parse(Android.jsValuesGet(0));
			cookie["bookid"] = id;
			sid = cookie["subjectId"];
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
		window.location.href = "subject-list.html?tbid="+id+"&sid="+subjectId;
	}
	else if(flag==2){
	window.location.href = "local-info.html?path="+escape(other);
	}
	else if(flag==3){
		if(typeof(Android)!="undefined"){
			var cookie = JSON.parse(Android.jsValuesGet(0));
			cookie["bookid"] = id;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
		window.location.href = "subject-list.html?tbid="+id;
	}
}
//20150402 全部缓存
function allCache(){
	loading({option:'close'});
//	setTimeout(function(){
	$('#allCache').popup('open');
//	},500);
	$('#cancle').unbind('click').bind('click',function(evt){
		setTimeout(function(){
		$('#allCache').popup('close');
		},500);
		evt.preventDefault();
		return;
	});
	
	$('#sure').unbind('click').bind('click',function(evt){
		$('#allCache').popup('close');
		javascript:downloadBook();
		evt.preventDefault();
		return;
	});
}
var isPlay = 0;//是否播放中
function writeLogPlayer(status,isLocal,isNew){
//    alert("log player");
	isPlay = status;
	var cookie = getCooke(0);
	var params = {};	
	params.subjectId = (isLocal==true) ? 'NULL' : getDataValue(cookie['subjectId'],'NULL');//科目id
	params.bookId = (isLocal==true) ? getDataValue(cookie["jsonData"].id,'NULL') : getDataValue(cookie["jsonData"].data.id,'NULL');//课本id
	params.bookName = (isLocal==true) ? getDataValue(cookie["jsonData"].name,'NULL') : getDataValue(cookie["jsonData"].data.name,'NULL');//课本名id
	params.sectionsId = [];//章节id数组
//	params.chapterId = (_treeNode && _treeNode.getParentNode()) ? _treeNode.getParentNode().id : 'NULL';//章id
//	params.partId = (_treeNode) ? _treeNode.id : 'NULL';//节id
	//params.assetsId = (_treeNode) ? _treeNode.dxid : 'NULL';//资源id,作业id、试卷id、导学id、题目id、记录id
	var filelist = cookie["filelist"];
	var _index = cookie["_index"];
	var dxid = "-1";
	if(filelist !='undefined'){
		dxid =  filelist[(_index-1)].dxid;
	}
	
	params.assetsId = getDataValue(dxid,'NULL');//资源id,作业id、试卷id、导学id、题目id、记录id
	params.AssetsName = 'NULL';//资源名称,我的课本章名称、学案文件
	params.visit = getDataValue(isNew,'0');//是否新的访问
	
	writeLog(1,status,params);
}
/*
测试过程写日志 
status:状态1=开始0=停止
isLocal:是否本地true,false
*/
function writeLogExam(status,isLocal){
//	alert("writeLogExam 129");
	var cookie = getCooke(0);
	var params = {};
	if(JSON.stringify(cookie)=='{}'){
		return;
	}
	params.subjectId = (isLocal==true) ? 'NULL' : getDataValue(cookie['subjectId'],'NULL');//科目id
	params.bookId = (isLocal==true) ? getDataValue(cookie["jsonData"].id,'NULL') : getDataValue(cookie["jsonData"].data.id,'NULL');//课本id
	params.bookName = (isLocal==true) ? getDataValue(cookie["jsonData"].name,'NULL') : getDataValue(cookie["jsonData"].data.name,'NULL');//课本名id
	params.sectionsId = [];//章节id数组
//	params.chapterId = 'NULL';//章id
//	params.partId = getDataValue(cookie["_treeNode"].id,'NULL');//节id
	var filelist = cookie["filelist"];
	var _index = cookie["_index"];
	var dxid = "-1";
	if(filelist !='undefined')
		dxid =  filelist[(_index-1)].dxid;
	params.assetsId = getDataValue(dxid,'NULL');//资源id,作业id、试卷id、导学id、题目id、记录id
	params.assetsName = 'NULL';//资源名称,我的课本章名称、学案文件
	params.visit = status.toString();//是否新的访问
	
	writeLog(2,status,params);
}