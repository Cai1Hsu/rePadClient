// JavaScript Document
var labelTitle = '我的作业-';

function showBook(flag,id,other){
    var type = 0;
    if(typeof(Android)!="undefined" && Android.getHomeworkType!="")
    {
        type = Android.getHomeworkType();
        
    }
    if(typeof(Android)!='undefined'&&typeof(Android.setWifiState)!='undefined')
    {
        Android.setWifiState(1);
    }
	if(flag==1){
//	window.location.href = "books.html?parent=index.html&sid="+id;
//	window.location.href = "remote-info.html?parent=index.html";
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
             if(type==1)
            {
                cookie["goback"] = "index-history.html";
                window.location.href = "books.html?parent=index-history.html&sid="+id;
            }else 
            {
                cookie["goback"] = "index.html";
                window.location.href = "books.html?parent=index.html&sid="+id;
            }
//			cookie["goback"] = "index.html";
			cookie["subjectId"] = id;
			cookie["filter"] = null;
            cookie["subjectName"] = other;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		//	Android.jsValuesSet(0,'{"goback":"index.html","subjectId":"'+id+'","filter":null}');
			
		}
	}
	else if(flag==2){
	window.location.href = "local-info.html?path="+escape(other);
	}
	else if(flag==3){
	window.location.href = "books.html?parent=history.html&sid="+id+"&filter=1";
//	window.location.href = "remote-info.html?parent=history.html";
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet)!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "history.html";
			cookie["subjectId"] = id;
			cookie["filter"] = 1;
            cookie["subjectName"] = other;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		//	Android.jsValuesSet(0,'{"goback":"history.html","subjectId":"'+id+'","filter":1}');
		}
	}
}
/*
查看科目对应书籍
flag:1=远程，2=本地
id:科目ID
other:其它数据
*/
function showBooks(flag,bookId,other,id){
    var type = 0;
    if(typeof(Android)!="undefined" && Android.getHomeworkType!="")
    {
        type = Android.getHomeworkType();
        
    }
  
	if(flag==1){
        if(type==1)
        {
            window.location.href = "history-subject-list.html?parent=books.html&sid="+id+"&tbid="+bookId;
        }else 
        {
            window.location.href = "subject-list.html?parent=books.html&sid="+id+"&tbid="+bookId;
        }
        
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet(0))!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
//			cookie["goback"] = "index.html";
            if(type==1)
            {
                cookie["goback"] = "books.html?parent=index-history.html";
            }else 
            {
                cookie["goback"] = "books.html?parent=index.html";
            }
			cookie["subjectId"] = id;
			cookie["sbookName"] = other;
			cookie["filter"] = null;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
	}
	else if(flag==2){
		window.location.href = "local-subject-list.html?path="+escape(other);
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet(0))!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["subjectName"] = null;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		}
	}
	else if(flag==3){
		window.location.href = "subject-list.html?parent=history.html";
		if(typeof(Android)!="undefined"){
			var cookie = {};
			if(typeof(Android.jsValuesGet(0))!='undefined' && Android.jsValuesGet(0)!=null && Android.jsValuesGet(0)!=""){
				cookie = JSON.parse(Android.jsValuesGet(0));
			}
			cookie["goback"] = "history.html";
			cookie["subjectId"] = id;
			cookie["subjectName"] = other;
			cookie["filter"] = 1;
			Android.jsValuesSet(0,JSON.stringify(cookie));
		//	Android.jsValuesSet(0,'{"goback":"history.html","subjectId":"'+id+'"}');
		}
	}
}
/*
播放视频写日志 
status:状态1=开始0=停止
isLocal:是否本地true,false
*/
function writeLogPlayer(status,isLocal,isNew){
	var cookie = getCooke(0);
	var params = {};
	params.subjectId = (isLocal==true) ? 'NULL' : getDataValue(cookie['subjectId'],'NULL');//科目id
	params.subjectId = (cookie["logData"]) ? getDataValue(cookie["logData"].subjectId,'NULL') : 'NULL';
	params.bookId = 'NULL';//课本id
	params.bookName = 'NULL';//课本名id
	var array = [];
	params.sectionsId = array;//章节id数组
	params.sectionsId = (cookie["logData"]) ? getDataValue(cookie["logData"].sectionsId,'NULL') : 'NULL';
	
//	params.chapterId = (_treeNode && _treeNode.getParentNode()) ? _treeNode.getParentNode().id : 'NULL';//章id
//	params.partId = (_treeNode) ? _treeNode.id : 'NULL';//节id

	var newrqid = 'NULL';
	if(jsonData.question[_index]){
		newrqid = getDataValue(jsonData.question[_index].newrqid,'NULL');
		if(newrqid=='NULL' || parseInt(newrqid,10)==0){
			newrqid = getDataValue(jsonData.question[_index].rid,'NULL');
		}
	}
	params.assetsId = newrqid;//资源id,作业id、试卷id、导学id、题目id、记录id
	params.assetsName = (jsonData.question[_index]) ? getDataValue(jsonData.question[_index].name,'NULL') : 'NULL';//资源名称,我的课本章名称、学案文件
	params.visit = getDataValue(isNew,'0');//是否新的访问
	
	writeLog(8,status,params);
}

/*
查看作业过程写日志 
status:状态1=开始0=停止
isLocal:是否本地true,false
*/
function writeLogShow(status,isLocal){
	
	var cookie = getCooke(0);
	var params = {};
//	params.subjectId = getDataValue(dataList[(_index-1)].subjectid,'NULL');//科目id
	params.subjectId = (cookie["logData"]) ? getDataValue(cookie["logData"].subjectId,'NULL') : 'NULL';
	params.bookId = 'NULL';//课本id
	params.bookName = 'NULL';//课本名id
//	params.sectionsId = (isLocal==true) ? [] : ((dataList[(_index-1)] && dataList[(_index-1)].chapterid && dataList[(_index-1)].partid) ? [dataList[(_index-1)].chapterid,dataList[(_index-1)].partid] : []);//章节id数组
	params.sectionsId = (cookie["logData"]) ? getDataValue(cookie["logData"].sectionsId,'NULL') : 'NULL';
//	params.chapterId = 'NULL';//章id
//	params.partId = getDataValue(cookie["_treeNode"].id,'NULL');//节id
	params.assetsId = (cookie["logData"]) ? getDataValue(cookie["logData"].assetsId,'NULL') : 'NULL';//资源id,作业id、试卷id、导学id、题目id、记录id
	params.assetsName = (cookie["logData"]) ? getDataValue(cookie["logData"].assetsName,'NULL') : 'NULL';//资源名称,我的课本章名称、学案文件
	params.visit = status.toString();//是否新的访问
	
	writeLog(7,status,params);
}

